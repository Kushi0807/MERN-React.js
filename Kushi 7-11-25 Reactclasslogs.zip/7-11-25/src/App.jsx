import React, { useEffect, useState } from "react";

function LoginForm({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!username || !password) {
      alert("Please enter both username and password!");
      return;
    }

    onLogin(username);
  };

  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h2>Login Page</h2>
      <form onSubmit={handleSubmit} autoComplete="off">

        <div>
          <label>Username: </label>
          <input type="text" value={username} onChange={(e) => setUsername(e.target.value)}/>
        </div>

        <div style={{ marginTop: "10px" }}>
          <label>Password: </label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}/>
        </div>

        <button type="submit" style={{ backgroundColor: "skyblue", marginTop: "10px" }}>
          Submit
        </button>
      </form>
    </div>
  );
}

function Gallery({ username, onLogout }) {
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadImages = async () => {
      try {
        const res = await fetch("https://picsum.photos/v2/list?page=1&limit=10");
        if (!res.ok) throw new Error(`Network error: ${res.status}`);
        const data = await res.json();
        setImages(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadImages();
  }, []);

  if (loading) return <p>Loading images...</p>;
  if (error) return <p>Failed to load images: {error}</p>;

  return (
    <div style={{ textAlign: "center" }}>
      <h1>Welcome, {username}! </h1>
      <button onClick={onLogout} style={{ marginBottom: "20px" }}>
        Logout
      </button>
      
      <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center" }}>
        {images.map((img) => (
          <div key={img.id} style={{ margin: "10px" }}>
            <img
              src={img.download_url}
              alt={img.author}
              style={{ width: "200px", height: "150px", objectFit: "cover" }}
            />
            <p>{img.author}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(null);

  return user ? (
    <Gallery username={user} onLogout={() => setUser(null)} />
  ) : (
    <LoginForm onLogin={(username) => setUser(username)} />
  );
}
